﻿#VERSION 1.2

Welcome to Star Parkour!
Created by Cosmic Creation (Thailand)

[NOTICE]

This map was designed for Minecraft 1.13.2 ONLY!

If you found a bug, Please report to https://megamc.in.th/CosmicCreation

[ALERT]

For Multiplayer Server, 

you MUST set in server.properties:
 - enabled-command-blocks enabled.

and set gamerule:
 - CommandBlockOutput false

[DONATE]

If you want to donate us, Donate at https://www.facebook.com/CosmicCreation.TH
:)

-CosmicCreationTeam

[Thai]
สำหรับคนไทยที่เล่นแมพนี้ พวกเราอยากเห็นพัฒนาการของแมพที่คนไทยสร้างมากขึ้นกว่านี้นะครับ :)